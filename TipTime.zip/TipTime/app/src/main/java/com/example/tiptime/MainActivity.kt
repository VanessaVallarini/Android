package com.example.tiptime

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tiptime.databinding.ActivityMainBinding
import java.text.NumberFormat

class MainActivity : AppCompatActivity() {

    /*
         Declara uma variável de nível superior na classe para o objeto de vinculação.
         Ela é definida nesse nível porque será usada em vários métodos da classe MainActivity
     */
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /*
             Inicializa o objeto binding que você usará para acessar as Views no layout
             activity_main.xml
         */
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.calculateButtonc.setOnClickListener{ calculateTip() }
    }

    private fun calculateTip() {
        //pegando o valor do xml EditText e transformando em double
        val stringInTextField = binding.costOfService.text.toString()
        val cost = stringInTextField.toDoubleOrNull()

        //verificando se cost é null e limpando o resultado do cálculo anterior
        if (cost == null || cost == 0.0) {
            displayTip(0.0)
            return
        }

        //pegando porcentagem de gorjeta, que o usuário selecionou em um RadioGroup de RadioButtons
        val tipPercentage = when (binding.tipOptions.checkedRadioButtonId) {
            R.id.option_twenty_percent -> 0.20
            R.id.option_eighteen_percent -> 0.18
            else -> 0.15
        }

        //calcular a gorjeta
        var tip = tipPercentage * cost

        //arredondar o valor se o usuário tiver selecionado essa opção
        if (binding.roundUpSwitch.isChecked) {
            tip = kotlin.math.ceil(tip)
        }

        displayTip(tip)
    }

    private fun displayTip(tip : Double) {
        //formatando o valor na moeda do idioma do usuário para exibí-la
        val formattedTip = NumberFormat.getCurrencyInstance().format(tip)
        //exibindo o valor para o usuário
        binding.tipResult.text = getString(R.string.tip_amount, formattedTip)
    }
}
