package br.com.fuiap.imcapplication

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import br.com.fuiap.imcapplication.databinding.ActivityMainBinding
import java.math.RoundingMode
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {

    /*
        Dados para teste:
            -- Negativo:
                peso: 80
                altura: 1.68
            -- Positivo:
                peso: 10
                altura: 1.68
            -- Meio termo:
                peso: 20
                altura: 1.68
     */
    private lateinit var binding: ActivityMainBinding

    private var calculateState = "inicio"

    private val INICIO = "inicio"
    private val RESULTADO_NEGATIVO = "negativo"
    private val RESULTADO_POSITIVO = "positivo"
    private val RESULTADO_MEIO_TERMO = "meio"
    private val ERROR = "error"

    private var calculateButton: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        //savedInstanceState: salva a instância do app, ex: dados que usuário inputa na tela
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState != null) {
            calculateState = savedInstanceState.getString(INICIO, "inicio")
        }

        setViewElements()

        calculateButton = findViewById(R.id.calcular)
        calculateButton!!.setOnClickListener {
            clickCalculateButton()
        }

    }

    private fun setViewElements(resultCalculateIMC : Double = 0.0) {

        val df = DecimalFormat("#.##")
        df.roundingMode = RoundingMode.CEILING
        val formattedCalculateIMC = df.format(resultCalculateIMC)

        val valuesString = when (calculateState) {
            RESULTADO_NEGATIVO -> {
                getString(R.string.calculo_result_negativo, formattedCalculateIMC)
            }
            RESULTADO_POSITIVO -> {
                getString(R.string.calculo_result_positivo, formattedCalculateIMC)
            }
            RESULTADO_MEIO_TERMO -> {
                getString(R.string.calculo_result_meio_termo, formattedCalculateIMC)
            }
            ERROR -> {
                getString(R.string.calculo_error)
            }
            else -> {getString(R.string.calculo_vamosCalcula)}
        }
        binding.textResult.text = valuesString

        val drawableResource = when (calculateState) {
            RESULTADO_NEGATIVO -> {
                R.drawable.imc_negativo
            }
            RESULTADO_POSITIVO -> {
                R.drawable.imc_positivo
            }
            RESULTADO_MEIO_TERMO -> {
                R.drawable.imc_positivo
            }
            ERROR -> {
                R.drawable.balanca
            }
            else -> {R.drawable.balanca}
        }
        binding.imageResult.setImageResource(drawableResource)
    }

    private fun clickCalculateButton(){
        val stringInTextFieldPeso = binding.editPeso.text.toString()
        val peso = stringInTextFieldPeso.toIntOrNull()

        val stringInTextFieldAltura = binding.editAltura.text.toString()
        val altura = stringInTextFieldAltura.toDoubleOrNull()

        if (peso == 0 || peso == null || altura == 0.0 || altura == null) {
            calculateState = "error"
            setViewElements()
            return
        }

        val calculateIMC = CalculateIMC(peso, altura)
        val resultCalculateIMC = calculateIMC.imc()

        if (calculateIMC.imc() > 10.0) {
            calculateState = "negativo"
            setViewElements(resultCalculateIMC)
            return
        }
        if (calculateIMC.imc() < 5.0) {
            calculateState = "positivo"
            setViewElements(resultCalculateIMC)
            return
        }
        if (calculateIMC.imc() >= 5.0 || calculateIMC.imc() <= 10.0) {
            calculateState = "meio"
            setViewElements(resultCalculateIMC)
            return
        }

        setViewElements()
    }

}

class CalculateIMC(p: Int = 1, a: Double = 1.0) {

    private val peso: Int = p
    private val altura: Double = a

    fun imc(): Double {
        return peso / (altura*altura)
    }
}