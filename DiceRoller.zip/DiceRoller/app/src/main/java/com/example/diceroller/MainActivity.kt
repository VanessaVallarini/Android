package com.example.diceroller

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

 /**
 * Esta atividade permite ao usuário lançar um dado e ver o resultado
 * na tela.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Pega o id do elemento da view.
        val rollButton: Button = findViewById(R.id.button)

        //Fica escutando quando ocorre uma ação no botão e executa a func rollDice().
        rollButton.setOnClickListener { rollDice() }

        // Exibir um dado com número aleatório ao iniciar o app pela primeira vez
        rollDice()

    }

     /**
      * RLance os dados e atualize a tela com o resultado.
      */
    private fun rollDice() {
        val dice = Dice(6) //criando uma instância do dado com 6 lados
        val diceRoll = dice.roll() //jogando o dado
        val diceImage: ImageView = findViewById(R.id.imageView) //pega o id do elemento da view (imageView)
         val drawableResource = when (diceRoll) {
             1 -> R.drawable.dice_1 //pega o recurso pelo nome
             2 -> R.drawable.dice_2
             3 -> R.drawable.dice_3
             4 -> R.drawable.dice_4
             5 -> R.drawable.dice_5
             else -> {R.drawable.dice_6} //como when retorna um valor, tem que ter uma opção de retorno caso nenhuma das outras de certo
         }
         diceImage.setImageResource(drawableResource) //adiciona o recurso no elemento da view
         diceImage.contentDescription = diceRoll.toString()// para que o usuário saiba o número que foi tirado
         //Os leitores de tela podem ler essa descrição de conteúdo em voz alta. Dessa forma, se o resultado da
         //imagem "6" for exibido na tela, a descrição do conteúdo será lida em voz alta como "6".

         //val resultTextView: TextView = findViewById(R.id.textView) //pega o id do elemento da view
         //resultTextView.text =
         //diceRoll.toString() //atribuindo o resultado do jogo na variável da tela
    }
}

class Dice(val numSides: Int) {

    fun roll(): Int {
        return (1..numSides).random()
    }

}