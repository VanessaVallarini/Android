/*
 * Copyright (C) 2021 The Android Open Source Project.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.lemonade

import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    /**
     * NÃO ALTERE QUAISQUER NOMES DE VARIÁVEIS OU VALORES OU SEUS VALORES INICIAIS.
     *
     * Espera-se que qualquer coisa rotulada var em vez de val seja alterada nas funções, mas NÃO
     * alterar seus valores iniciais declarados aqui, isso pode fazer com que o aplicativo não funcione corretamente.
     */
    private val LEMONADE_STATE = "LEMONADE_STATE"
    private val LEMON_SIZE = "LEMON_SIZE"
    private val SQUEEZE_COUNT = "SQUEEZE_COUNT"
    // SELECT representa o estado "escolher limão"
    private val SELECT = "select"
    // SQUEEZE representa o estado "squeeze lemon"
    private val SQUEEZE = "squeeze"
    // DRINK representa o estado de "beber limonada"
    private val DRINK = "drink"
    // RESTART representa o estado onde a limonada foi bebida e o copo está vazio
    private val RESTART = "restart"
    // Padrão o estado para selecionar
    private var lemonadeState = "select"
    // Default lemonSize to -1
    private var lemonSize = -1
    // Default the squeezeCount to -1
    private var squeezeCount = -1

    // Cria uma instância de Limão
    private var lemonTree = LemonTree()
    // Seta a imagem como null
    private var lemonImage: ImageView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // === NÃO ALTERE O CÓDIGO NA SEGUINTE SE DECLARAÇÃO ===
        if (savedInstanceState != null) {
            lemonadeState = savedInstanceState.getString(LEMONADE_STATE, "select") //o estado inicia em select
            lemonSize = savedInstanceState.getInt(LEMON_SIZE, -1) //o valor randômico inicia em -1
            squeezeCount = savedInstanceState.getInt(SQUEEZE_COUNT, -1) //a quantidade de cliques inicia em -1
        }
        // === END IF DECLARAÇÃO ===

        lemonImage = findViewById(R.id.image_lemon_state)
        setViewElements() //configurando a imagem a ser exibida de acordo com o estado

        lemonImage!!.setOnClickListener {
            // TODO: chame o método que controla o estado quando a imagem é clicada
            clickLemonImage()
        }

        lemonImage!!.setOnLongClickListener {
            // TODO: substitua 'false' por uma chamada para a função que mostra a contagem de compressão
            //false
            showSnackbar()
        }
    }

    /**
     * === NÃO ALTERE ESTE MÉTODO ===
     *
     * Este método salva o estado do aplicativo se ele for colocado em segundo plano.
     */
    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString(LEMONADE_STATE, lemonadeState)
        outState.putInt(LEMON_SIZE, lemonSize)
        outState.putInt(SQUEEZE_COUNT, squeezeCount)
        super.onSaveInstanceState(outState)
    }

    /**
     * Ao clicar, você obterá uma resposta diferente dependendo do estado.
     * Este método determina o estado e prossegue com a ação correta.
     */
    private fun clickLemonImage() {
        // TODO: use uma declaração condicional como 'if' ou 'when' para rastrear o LemonadeState
        //  quando a imagem é clicada, podemos precisar mudar o estado para a próxima etapa no
        //  limonada fazendo progressão (ou pelo menos fazer algumas mudanças no estado atual no
        //  caso de espremer o limão). Isso deve ser feito nesta declaração condicional

        // TODO: Quando a imagem é clicada no estado SELECT, o estado deve se tornar SQUEEZE
        //  - A variável lemonSize precisa ser definida usando o método 'pick ()' na classe LemonTree
        //  - O squeezeCount deve ser 0, pois ainda não esprememos nenhum limão.

        // TODO: Quando a imagem é clicada no estado SQUEEZE, o squeezeCount precisa ser
        //  AUMENTADO em 1 e o lemonSize precisa ser REDUZIDO em 1.
        //  - Se o LemonSize atingiu 0, ele foi espremido e o estado deve se tornar BEBIDA
        //  - Além disso, lemonSize não é mais relevante e deve ser definido como -1

        // TODO: Quando a imagem é clicada no estado BEBIDA, o estado deve se tornar RESTART

        // TODO: Quando a imagem é clicada no estado RESTART, o estado deve se tornar SELECT

        // TODO: por último, antes que a função termine, precisamos definir os elementos de visualização para que o
        //  IU pode refletir o estado correto

        when (lemonadeState) {
            SELECT -> {
                lemonadeState = "squeeze"
                lemonSize = lemonTree.pick()
                squeezeCount = 0
            }
            SQUEEZE -> {
                lemonSize -= 1
                squeezeCount += 1
                if(lemonSize == 0) {
                    lemonadeState = "drink"
                }
            }
            DRINK -> {
                lemonadeState = "restart"
                lemonSize = -1
            }
            else -> {
                lemonadeState = "select"
            }
        }

        setViewElements()
    }

    /**
     * Configure os elementos da vista de acordo com o estado.
     */
    private fun setViewElements() {
        val textAction: TextView = findViewById(R.id.text_action) //pega o id do elemento da view

        // TODO: configurar uma condicional que rastreia o estado de limonada

        // TODO: para cada estado, o textAction TextView deve ser definido para a string correspondente de
        //  // o arquivo de recursos da string. As strings são nomeadas para corresponder ao estado

        // TODO: Além disso, para cada estado, o LemonImage deve ser definido para o correspondente
        //  // drawable a partir dos recursos drawable. Os drawables têm os mesmos nomes das strings
        //  // mas lembre-se de que eles são drawables, não strings.

        val valuesString = when (lemonadeState) {
            SELECT -> getString(R.string.lemon_select) //pega o recurso pelo nome
            SQUEEZE -> getString(R.string.lemon_squeeze) //pega o recurso pelo nome
            DRINK -> getString(R.string.lemon_drink)
            RESTART -> getString(R.string.lemon_empty_glass)
            else -> {getString(R.string.squeeze_count)} //como when retorna um valor, tem que ter uma opção de retorno caso nenhuma das outras de certo
        }
        textAction.text = valuesString

        val drawableResource = when (lemonadeState) {
            SQUEEZE -> R.drawable.lemon_squeeze //pega o recurso pelo nome
            DRINK -> R.drawable.lemon_drink
            RESTART -> R.drawable.lemon_restart
            else -> {R.drawable.lemon_tree} //como when retorna um valor, tem que ter uma opção de retorno caso nenhuma das outras de certo
        }
        lemonImage?.setImageResource(drawableResource)
    }

    /**
     * === NÃO ALTERE ESTE MÉTODO ===
     *
     * Um clique longo na imagem do limão mostrará quantas vezes o limão foi espremido.
     */
    private fun showSnackbar(): Boolean {
        if (lemonadeState != SQUEEZE) {
            return false
        }
        val squeezeText = getString(R.string.squeeze_count, squeezeCount)
        Snackbar.make(
            findViewById(R.id.constraint_Layout),
            squeezeText,
            Snackbar.LENGTH_SHORT
        ).show()
        return true
    }
}

/**
 * Uma aula de Limoeiro com um método para "colher" um limão. O "tamanho" do limão é aleatório
 * e determina quantas vezes um limão precisa ser espremido antes de você começar a limonada.
 */
class LemonTree {
    fun pick(): Int {
        return (2..4).random()
    }
}
